package thirdTask;

import java.util.Scanner;

interface GUIFactory
{
    Button createButton();
    Checkbox createCheckbox();
}

public class WinFactory implements GUIFactory {
    @Override
    public Button createButton() {
        return new WinButton();
    }

    @Override
    public Checkbox createCheckbox() {
        return new WinCheckBox();
    }
}

class MacFactory implements GUIFactory
{
    @Override
    public Button createButton() {
        return new MacButton();
    }

    @Override
    public Checkbox createCheckbox() {
        return new MacCheckBox();
    }
}

interface Button
{
    void paint();
}

class WinButton implements Button{
    @Override
    public void paint()
    {
        System.out.println("painting Win button...");
    }
}

class MacButton implements Button{
    @Override
    public void paint()
    {
        System.out.println("painting Mac button...");
    }
}

interface Checkbox{
    public void paint();
}

class WinCheckBox implements Checkbox{
    @Override
    public void paint()
    {
        System.out.println("Win check box calling...");
    }
}

class MacCheckBox implements Checkbox{
    @Override
    public void paint()
    {
        System.out.println("Mac check box calling...");
    }
}

class Application
{
    private GUIFactory factory;
    private Button button;

    Application(GUIFactory factory)
    {
        this.factory = factory;
    }

    void createUI()
    {
        this.button = factory.createButton();
    }
    void paint()
    {
        button.paint();
    }
}

class ApplicationConfigurator
{
    public static void main(String[] args) throws Exception {
        Scanner in = new Scanner(System.in);

        String config = in.next();

        if(config.equals("Windows"))
        {
            WinFactory factory = new WinFactory();
            Application app = new Application(factory);
        }
        else if(config.equals("Mac"))
        {
            MacFactory factory = new MacFactory();
            Application app = new Application(factory);
        }
        else
        {
            throw new Exception("Error! Unknown operating system.");
        }
    }
}
