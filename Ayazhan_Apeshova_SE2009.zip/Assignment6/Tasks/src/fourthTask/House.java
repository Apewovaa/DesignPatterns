package fourthTask;
class House
{
    private String walls;
    private String doors;
    private String windows;
    private String roof;
    private String garage;

    public void setWalls(String walls) {
        this.walls = walls;
    }

    public void setDoors(String doors) {
        this.doors = doors;
    }

    public void setWindows(String windows) {
        this.windows = windows;
    }

    public void setRoof(String roof) {
        this.roof = roof;
    }

    public void setGarage(String garage) {
        this.garage = garage;
    }
}


interface HouseBuilder
{

    public void buildWalls();

    public void buildDoors();

    public void buildWindows();

    public void buildRoof();

    public void buildGarage();

    public House getHouse();
}

class TreeHouseBuilder implements HouseBuilder
{
    private House house;

    public TreeHouseBuilder()
    {
        this.house = new House();
    }

    @Override
    public void buildWalls()
    {
        house.setWalls("Tree walls");
    }

    @Override
    public void buildDoors()
    {
        house.setDoors("Tree Doors");
    }

    @Override
    public void buildWindows()
    {
        house.setWindows("Tree Windows");
    }

    @Override
    public void buildRoof()
    {
        house.setRoof("Tree roof");
    }

    @Override
    public void buildGarage() {
        house.setGarage("Tree garage");
    }

    public House getHouse()
    {
        return this.house;
    }
}

class BungalowHouseBuilder implements HouseBuilder
{
    private House house;

    public BungalowHouseBuilder()
    {
        this.house = new House();
    }

    @Override
    public void buildWalls()
    {
        house.setWalls("Bungalow walls");
    }

    @Override
    public void buildDoors()
    {
        house.setDoors("Bungalow Doors");
    }

    @Override
    public void buildWindows()
    {
        house.setWindows("Bungalow Windows");
    }

    @Override
    public void buildRoof()
    {
        house.setRoof("Bungalow roof");
    }

    @Override
    public void buildGarage()
    {
        house.setGarage("Bungalow garage");
    }
    public House getHouse()
    {
        return this.house;
    }

}

class BuildingEngineer
{

    private HouseBuilder builder;

    public BuildingEngineer(HouseBuilder builder)
    {
        this.builder = builder;
    }

    public void constructHouse()
    {
        this.builder.buildWalls();
        this.builder.buildDoors();
        this.builder.buildWindows();
        this.builder.buildRoof();
        this.builder.buildGarage();
    }

    public House getHouse()
    {
        return this.builder.getHouse();
    }
}

class Builder
{
    public static void main(String[] args)
    {
        HouseBuilder treeHouseBuilder = new TreeHouseBuilder();

        BuildingEngineer buildingEngineer = new BuildingEngineer(treeHouseBuilder);

        buildingEngineer.constructHouse();
        House house = buildingEngineer.getHouse();
        System.out.println(house);
    }
} 