package firstTask;
import java.sql.*;

public class Database {
    private static Database instance;

    private Database(){

        String URL = "jdbc:postgresql://localhost:5432/postgres";
        String username = "postgres";
        String password = "password";
        try {
            Connection connection = DriverManager.getConnection(URL, username, password);
        }
        catch(SQLException exception)
        {
            exception.printStackTrace();
        }
    }

    public static Database getInstance()
    {
        if(instance == null)
        {
            instance = new Database();
        }
        return instance;
    }

    public void query(String sql) throws SQLException {
        String URL = "jdbc:postgresql://localhost:5432/patterns";
        String username = "postgres";
        String password = "password";

        Connection connection = DriverManager.getConnection(URL , username, password);
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery(sql);
        while(rs.next())
        {
            System.out.println("ID: " + rs.getInt(1) + ", value = " + rs.getInt(2));
        }
    }


}

class Application
{
    public static void main(String[] args) throws SQLException {

        Database foo =  Database.getInstance();
        foo.query("SELECT * from queries");

        Database bar = Database.getInstance();
        foo.query("SELECT * from queries");
    }
}